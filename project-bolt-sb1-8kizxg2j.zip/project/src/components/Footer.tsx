import React from 'react';
import { Mail, MapPin, Phone } from 'lucide-react';

const Footer = () => {
  return (
    <footer id="contact" className="bg-gray-900 pt-20 pb-10">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          <div>
            <h3 className="font-['Press_Start_2P'] text-xl mb-6 text-[#04f384]">Contact</h3>
            <ul className="space-y-4">
              <li className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-[#04f384]" />
                <span>contact@sixeight.gg</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-[#04f384]" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-[#04f384]" />
                <span>123 Gaming Street, Esports City</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-['Press_Start_2P'] text-xl mb-6 text-[#04f384]">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#about" className="hover:text-[#04f384] transition-colors">About Us</a></li>
              <li><a href="#services" className="hover:text-[#04f384] transition-colors">Services</a></li>
              <li><a href="#register" className="hover:text-[#04f384] transition-colors">Register</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-['Press_Start_2P'] text-xl mb-6 text-[#04f384]">Newsletter</h3>
            <p className="mb-4">Stay updated with our latest tournaments and events.</p>
            <form className="flex">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 bg-gray-800 rounded-l px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
              />
              <button
                type="submit"
                className="bg-[#04f384] text-gray-900 font-bold px-4 rounded-r hover:bg-[#04853a] transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="text-center pt-8 border-t border-gray-800">
          <p>&copy; 2025 Six Eight. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;