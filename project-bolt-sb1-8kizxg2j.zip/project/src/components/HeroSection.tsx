import React from 'react';
import { ChevronDown } from 'lucide-react';

const HeroSection = () => {
  return (
    <div className="relative min-h-screen flex items-center justify-center bg-[url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80')] bg-cover bg-center">
      <div className="absolute inset-0 bg-gray-900/70"></div>
      <div className="relative text-center px-4">
        <h1 className="font-['Press_Start_2P'] text-4xl md:text-6xl mb-6 leading-tight">
          SHAPE THE FUTURE
          <br />
          OF <span className="text-[#04f384]">ESPORTS</span>
        </h1>
        <p className="font-['Orbitron'] text-xl md:text-2xl mb-8 text-gray-300">
          Join the next generation of competitive gaming
        </p>
        <button className="bg-[#04f384] text-gray-900 font-['Orbitron'] font-bold px-8 py-3 rounded-lg hover:bg-[#04853a] transition-colors">
          Join Now
        </button>
      </div>
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-8 h-8 text-[#04f384]" />
      </div>
    </div>
  );
};

export default HeroSection;