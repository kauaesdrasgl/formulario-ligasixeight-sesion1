import React from 'react';
import { Trophy, Users, Gamepad2 } from 'lucide-react';

const AboutSection = () => {
  return (
    <section id="about" className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="font-['Press_Start_2P'] text-3xl text-center mb-16">
          About <span className="text-[#04f384]">Six Eight</span>
        </h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center p-6 bg-gray-900 rounded-lg hover:scale-105 transition-transform">
            <Trophy className="w-12 h-12 text-[#04f384] mx-auto mb-4" />
            <h3 className="font-['Orbitron'] text-xl mb-4">Our Mission</h3>
            <p className="text-gray-400">
              Expanding esports opportunities and transforming gaming into a path for personal and professional growth.
            </p>
          </div>

          <div className="text-center p-6 bg-gray-900 rounded-lg hover:scale-105 transition-transform">
            <Users className="w-12 h-12 text-[#04f384] mx-auto mb-4" />
            <h3 className="font-['Orbitron'] text-xl mb-4">Community</h3>
            <p className="text-gray-400">
              Building an inclusive gaming community through education and technological innovation.
            </p>
          </div>

          <div className="text-center p-6 bg-gray-900 rounded-lg hover:scale-105 transition-transform">
            <Gamepad2 className="w-12 h-12 text-[#04f384] mx-auto mb-4" />
            <h3 className="font-['Orbitron'] text-xl mb-4">Innovation</h3>
            <p className="text-gray-400">
              Pioneering the future of competitive gaming with state-of-the-art facilities and training programs.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;