import React, { useState } from 'react';
import { Upload, Plus, Minus, Send } from 'lucide-react';

interface PlayerData {
  name: string;
  nickname: string;
  playerId: string;
  position: string;
  phone: string;
  email: string;
  cpf: string;
  birthdate: string;
}

interface TeamData {
  teamName: string;
  teamTag: string;
  teamLogo: File | null;
  noLogo: boolean;
  ownerName: string;
  ownerNickname: string;
  teamInstagram: string;
  ownerPhone: string;
  ownerCpf: string;
  ownerEmail: string;
  ownerBirthdate: string;
  players: PlayerData[];
  hasReservePlayer: boolean;
}

const initialPlayerData: PlayerData = {
  name: '',
  nickname: '',
  playerId: '',
  position: 'Rush',
  phone: '',
  email: '',
  cpf: '',
  birthdate: '',
};

const RegistrationSection = () => {
  const [formData, setFormData] = useState<TeamData>({
    teamName: '',
    teamTag: '',
    teamLogo: null,
    noLogo: false,
    ownerName: '',
    ownerNickname: '',
    teamInstagram: '',
    ownerPhone: '',
    ownerCpf: '',
    ownerEmail: '',
    ownerBirthdate: '',
    players: Array(4).fill(initialPlayerData),
    hasReservePlayer: false,
  });

  const handleTeamInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({
      ...prev,
      teamLogo: file,
      noLogo: false
    }));
  };

  const handlePlayerChange = (index: number, field: keyof PlayerData, value: string) => {
    setFormData(prev => ({
      ...prev,
      players: prev.players.map((player, i) => 
        i === index ? { ...player, [field]: value } : player
      )
    }));
  };

  const toggleReservePlayer = () => {
    setFormData(prev => ({
      ...prev,
      hasReservePlayer: !prev.hasReservePlayer,
      players: prev.hasReservePlayer 
        ? prev.players.slice(0, 4)
        : [...prev.players, { ...initialPlayerData }]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Handle form submission
  };

  const renderPlayerForm = (index: number, isReserve: boolean = false) => {
    const player = formData.players[index];
    const title = index === 0 ? 'Capitão (CPT)' : isReserve ? 'Reserva' : `Player ${index + 1}`;

    return (
      <div className="bg-gray-800 p-6 rounded-lg">
        <h3 className="font-['Press_Start_2P'] text-xl mb-6 text-[#04f384]">{title}</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-['Orbitron'] mb-2">Nome Completo</label>
            <input
              type="text"
              value={player.name}
              onChange={(e) => handlePlayerChange(index, 'name', e.target.value)}
              className="w-full bg-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
              required
            />
          </div>
          <div>
            <label className="block font-['Orbitron'] mb-2">Nickname</label>
            <input
              type="text"
              value={player.nickname}
              onChange={(e) => handlePlayerChange(index, 'nickname', e.target.value)}
              className="w-full bg-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
              required
            />
          </div>
          <div>
            <label className="block font-['Orbitron'] mb-2">ID do Jogador</label>
            <input
              type="text"
              value={player.playerId}
              onChange={(e) => handlePlayerChange(index, 'playerId', e.target.value)}
              className="w-full bg-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
              maxLength={12}
              required
            />
          </div>
          <div>
            <label className="block font-['Orbitron'] mb-2">Posição</label>
            <select
              value={player.position}
              onChange={(e) => handlePlayerChange(index, 'position', e.target.value)}
              className="w-full bg-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
              required
            >
              <option value="Rush">Rush</option>
              <option value="Suporte">Suporte</option>
              <option value="Granadeiro">Granadeiro</option>
              <option value="Curandeiro">Curandeiro</option>
              <option value="Outros">Outros</option>
            </select>
          </div>
          <div>
            <label className="block font-['Orbitron'] mb-2">Contato</label>
            <input
              type="tel"
              value={player.phone}
              onChange={(e) => handlePlayerChange(index, 'phone', e.target.value)}
              className="w-full bg-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
              placeholder="(XX) XXXXX-XXXX"
              required
            />
          </div>
          <div>
            <label className="block font-['Orbitron'] mb-2">E-mail</label>
            <input
              type="email"
              value={player.email}
              onChange={(e) => handlePlayerChange(index, 'email', e.target.value)}
              className="w-full bg-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
              required
            />
          </div>
          <div>
            <label className="block font-['Orbitron'] mb-2">CPF</label>
            <input
              type="text"
              value={player.cpf}
              onChange={(e) => handlePlayerChange(index, 'cpf', e.target.value)}
              className="w-full bg-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
              placeholder="XXX.XXX.XXX-XX"
              required
            />
          </div>
          <div>
            <label className="block font-['Orbitron'] mb-2">Data de Nascimento</label>
            <input
              type="date"
              value={player.birthdate}
              onChange={(e) => handlePlayerChange(index, 'birthdate', e.target.value)}
              className="w-full bg-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
              required
            />
          </div>
        </div>
      </div>
    );
  };

  return (
    <section id="register" className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="font-['Press_Start_2P'] text-3xl text-center mb-16">
          Register Your <span className="text-[#04f384]">Team</span>
        </h2>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Team Information */}
          <div className="bg-gray-900 p-8 rounded-lg">
            <h3 className="font-['Press_Start_2P'] text-2xl mb-8 text-[#04f384]">Informações do Time</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block font-['Orbitron'] mb-2">Nome do Time</label>
                <input
                  type="text"
                  name="teamName"
                  value={formData.teamName}
                  onChange={handleTeamInfoChange}
                  className="w-full bg-gray-800 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
                  required
                />
              </div>
              <div>
                <label className="block font-['Orbitron'] mb-2">Tag do Time</label>
                <input
                  type="text"
                  name="teamTag"
                  value={formData.teamTag}
                  onChange={handleTeamInfoChange}
                  className="w-full bg-gray-800 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
                  required
                />
              </div>
              <div>
                <label className="block font-['Orbitron'] mb-2">Logo do Time</label>
                <div className="flex items-center space-x-4">
                  <label className="flex items-center px-4 py-2 bg-gray-800 rounded cursor-pointer hover:bg-gray-700 transition-colors">
                    <Upload className="w-5 h-5 mr-2 text-[#04f384]" />
                    <span>Escolher arquivo</span>
                    <input
                      type="file"
                      onChange={handleFileChange}
                      className="hidden"
                      accept="image/*"
                      disabled={formData.noLogo}
                    />
                  </label>
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      name="noLogo"
                      checked={formData.noLogo}
                      onChange={handleTeamInfoChange}
                      className="mr-2"
                    />
                    <span>Time sem Logo</span>
                  </div>
                </div>
              </div>
              <div>
                <label className="block font-['Orbitron'] mb-2">Nome Completo do Dono</label>
                <input
                  type="text"
                  name="ownerName"
                  value={formData.ownerName}
                  onChange={handleTeamInfoChange}
                  className="w-full bg-gray-800 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
                  required
                />
              </div>
              <div>
                <label className="block font-['Orbitron'] mb-2">Como é Conhecido</label>
                <input
                  type="text"
                  name="ownerNickname"
                  value={formData.ownerNickname}
                  onChange={handleTeamInfoChange}
                  className="w-full bg-gray-800 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
                  required
                />
              </div>
              <div>
                <label className="block font-['Orbitron'] mb-2">Instagram do Time</label>
                <input
                  type="text"
                  name="teamInstagram"
                  value={formData.teamInstagram}
                  onChange={handleTeamInfoChange}
                  className="w-full bg-gray-800 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
                />
              </div>
              <div>
                <label className="block font-['Orbitron'] mb-2">Contato do Dono</label>
                <input
                  type="tel"
                  name="ownerPhone"
                  value={formData.ownerPhone}
                  onChange={handleTeamInfoChange}
                  className="w-full bg-gray-800 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
                  placeholder="(XX) XXXXX-XXXX"
                  required
                />
              </div>
              <div>
                <label className="block font-['Orbitron'] mb-2">CPF do Dono</label>
                <input
                  type="text"
                  name="ownerCpf"
                  value={formData.ownerCpf}
                  onChange={handleTeamInfoChange}
                  className="w-full bg-gray-800 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
                  placeholder="XXX.XXX.XXX-XX"
                  required
                />
              </div>
              <div>
                <label className="block font-['Orbitron'] mb-2">E-mail do Dono</label>
                <input
                  type="email"
                  name="ownerEmail"
                  value={formData.ownerEmail}
                  onChange={handleTeamInfoChange}
                  className="w-full bg-gray-800 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
                  required
                />
              </div>
              <div>
                <label className="block font-['Orbitron'] mb-2">Data de Nascimento</label>
                <input
                  type="date"
                  name="ownerBirthdate"
                  value={formData.ownerBirthdate}
                  onChange={handleTeamInfoChange}
                  className="w-full bg-gray-800 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#04f384]"
                  required
                />
              </div>
            </div>
          </div>

          {/* Players Section */}
          <div className="space-y-6">
            <h3 className="font-['Press_Start_2P'] text-2xl text-center mb-8 text-[#04f384]">Jogadores</h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {formData.players.map((_, index) => renderPlayerForm(index))}
            </div>

            {/* Reserve Player Controls */}
            <div className="flex justify-center space-x-4">
              <button
                type="button"
                onClick={toggleReservePlayer}
                className="flex items-center px-6 py-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
              >
                {formData.hasReservePlayer ? (
                  <>
                    <Minus className="w-5 h-5 mr-2 text-[#04f384]" />
                    <span>Remover Reserva</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-5 h-5 mr-2 text-[#04f384]" />
                    <span>Adicionar Reserva</span>
                  </>
                )}
              </button>
            </div>

            {formData.hasReservePlayer && (
              <div className="mt-6">
                {renderPlayerForm(4, true)}
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="flex justify-center">
            <button
              type="submit"
              className="flex items-center px-8 py-4 bg-[#04f384] text-gray-900 rounded-lg font-['Orbitron'] font-bold hover:bg-[#04853a] transition-colors"
            >
              <Send className="w-5 h-5 mr-2" />
              Enviar Cadastro
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};

export default RegistrationSection;