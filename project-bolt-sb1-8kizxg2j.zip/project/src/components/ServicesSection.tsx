import React from 'react';
import { Swords, Users, Laptop } from 'lucide-react';

const ServicesSection = () => {
  return (
    <section id="services" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="font-['Press_Start_2P'] text-3xl text-center mb-16">
          Our <span className="text-[#04f384]">Services</span>
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              icon: <Swords className="w-12 h-12" />,
              title: "Daily Tournaments",
              description: "Compete in daily Battle Royale, 4v4, and custom game modes with cash prizes.",
            },
            {
              icon: <Users className="w-12 h-12" />,
              title: "Gaming Arena",
              description: "State-of-the-art gaming facility with professional equipment and coaching.",
            },
            {
              icon: <Laptop className="w-12 h-12" />,
              title: "Tech Education",
              description: "Learn game development, streaming, and esports management skills.",
            },
          ].map((service, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-lg bg-gray-800 p-6 hover:bg-gray-700 transition-colors"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#04f384]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative">
                <div className="mb-4 text-[#04f384]">{service.icon}</div>
                <h3 className="font-['Orbitron'] text-xl mb-4">{service.title}</h3>
                <p className="text-gray-400">{service.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;