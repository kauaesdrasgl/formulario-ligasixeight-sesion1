import React from 'react';
import { ChevronDown, Trophy, Users, Gamepad2, ScrollText, Mail } from 'lucide-react';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import ServicesSection from './components/ServicesSection';
import RegistrationSection from './components/RegistrationSection';
import Footer from './components/Footer';

function App() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Navigation */}
      <nav className="fixed w-full bg-gray-900/90 backdrop-blur-sm z-50 border-b border-[#04f384]/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Gamepad2 className="w-8 h-8 text-[#04f384]" />
              <span className="text-2xl font-['Orbitron'] font-bold">SIX EIGHT</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              {[
                { name: 'About', href: 'about' },
                { name: 'Services', href: 'services' },
                { name: 'Register', href: 'register' },
                { name: 'Contact', href: 'contact' },
              ].map((item) => (
                <button
                  key={item.name}
                  onClick={() => scrollToSection(item.href)}
                  className="font-['Orbitron'] hover:text-[#04f384] transition-colors"
                >
                  {item.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      <main>
        <HeroSection />
        <AboutSection />
        <ServicesSection />
        <RegistrationSection />
      </main>

      <Footer />
    </div>
  );
}

export default App;